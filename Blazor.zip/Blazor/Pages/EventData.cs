public class EventData {
    public string Name { get; set; }
    public DateTime Date { get; set; }
    public string Description { get; set; }
}
