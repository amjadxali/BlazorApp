using System.ComponentModel.DataAnnotations;

public class Participant
{
        [Required(ErrorMessage = "Full name required.")]
        public string? FullName { get; set; }

        [Required(ErrorMessage = "Email address required.")]
        [EmailAddress(ErrorMessage = "Invalid email address.")]
        public string? Email { get; set; }

        [Required(ErrorMessage = "Event is required.")]
        public int EventId { get; set; }
}