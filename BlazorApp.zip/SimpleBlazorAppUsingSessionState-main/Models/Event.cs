using System;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace EventEaseApp.Models
{
    public class Event
    {
        public Event() //needed for deserializing from local storage
        {
            
        }
        public Event(bool generateId = false)
        {
            if(generateId)
                Id = SessionStateService._nextId++;
            else
                Id = (-1)* SessionStateService._nextId++;

        }

        [Required(ErrorMessage = "Event name is required.")]
        public string Name { get; set; }

        [Required(ErrorMessage = "Valid date is required.")]
        public DateTime Date { get; set; }

        [Required(ErrorMessage = "Event location is required.")]
        public string Location { get; set; }

        public int? Id { get; set; }
    }
}
