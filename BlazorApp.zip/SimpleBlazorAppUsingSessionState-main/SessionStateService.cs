using EventEaseApp.Models;
using Microsoft.JSInterop;
using System.Collections.Generic;
using System.Text.Json;
using System.Threading.Tasks;

public class SessionStateService
{
    public static readonly string EventsListName = "EventsList7";
    public static readonly string ParticipantsListName = "Participants";

    public static int _nextId = 1;
    private readonly IJSRuntime _jsRuntime;

    public SessionStateService(IJSRuntime jsRuntime)
    {
        _jsRuntime = jsRuntime;
        //InitialLoad().Wait();
    }

    public async Task InitialLoad()
    {
        List<Event> initialEvents = new List<Event>
        {
            // not used
            new Event(true) { Name = "Corporate Meeting", Date = DateTime.Now.AddDays(10), Location = "New York" },
            new Event(true) { Name = "Social Gala", Date = DateTime.Now.AddDays(20), Location = "Los Angeles" },
            new Event(true) { Name = "Tech Conference", Date = DateTime.Now.AddDays(30), Location = "San Francisco" }
        };

        await SaveEventListAsync(initialEvents);
    }

    private async Task SaveEventListAsync(List<Event> events)
    {
        var eventsJson = JsonSerializer.Serialize(events);
        await _jsRuntime.InvokeVoidAsync("localStorage.setItem", EventsListName, eventsJson);
    }


    private async Task SaveParticipantsListAsync(List<Participant> participants)
    {
        var participantsJson = JsonSerializer.Serialize(participants);
        await _jsRuntime.InvokeVoidAsync("localStorage.setItem", ParticipantsListName, participantsJson);
    }


    private async Task<List<Event>> LoadEventListAsync()
    {
        var eventsJson = await _jsRuntime.InvokeAsync<string>("localStorage.getItem", EventsListName);
        var results =  eventsJson == null ? new List<Event>() : JsonSerializer.Deserialize<List<Event>>(eventsJson);
        _nextId = results.Count > 0 ? results.Max(e => e.Id).Value + 1 : 1;  
        return results;
    }

    private async Task<List<Participant>> LoadParticipantsListAsync()
    {
        var participantsJson = await _jsRuntime.InvokeAsync<string>("localStorage.getItem", ParticipantsListName);
        var results =  participantsJson == null ? new List<Participant>() : JsonSerializer.Deserialize<List<Participant>>(participantsJson);
        return results;
    }



    public async Task<int?> AddOrUpdateEventAsync(Event eventItem)
    {
        var events = await LoadEventListAsync(); //get all saved events

        var x = events.Where(e => e.Id == eventItem.Id).FirstOrDefault(); //update the event
       
       int? eventId = eventItem.Id;
        if(x!=null && eventItem.Id> 0){  //only saving edits to an existing event
            x.Name = eventItem.Name;
            x.Date = eventItem.Date;
            x.Location = eventItem.Location;
        }
        else //new event, save it!
        {
            var newEvent = new Event(true)
            {
                Name = eventItem.Name,
                Date = eventItem.Date,
                Location = eventItem.Location
            };
            events.Add(newEvent);
            eventId = newEvent.Id;
        }

        await SaveEventListAsync(events); //save the updated list
        return eventId;
    }

    public async Task AddParticipantAsync(Participant participant)
    {
        var participants = await LoadParticipantsListAsync(); //get all saved participants
        participants.Add(participant); //add the new participant
       
        await SaveParticipantsListAsync(participants); //save the updated list
    }


    public async Task RemoveEventAsync(Event eventItem)
    {
        var events = await LoadEventListAsync();
        events.RemoveAll(e => e.Id == eventItem.Id);
        await SaveEventListAsync(events);
    }

    public async Task<List<Event>> GetEventsAsync()
    {
        return await LoadEventListAsync();
    }
    public async Task<List<Participant>> GetParticipantsAsync()
    {
        return await LoadParticipantsListAsync();
    }
}
